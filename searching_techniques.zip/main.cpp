/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<iostream>
using namespace std;
void Linear(int a[],int n){
      int i,key,flag=0;
      cout<<"\nLinear Search\n"<<endl;
              cout<<"Enter key element :";
     cin>>key;
               for(i=0;i<n;i++){
                if(key==a[i]){
                    flag=1;
                    break;
                }
               }
               if(flag==1){
                cout<<"key elemnt" <<key<<" is found at" <<i<<" position"<<endl;
               }
               else{
                cout<<"key elemnt is not found"<<endl;
               }
}
void Binary(int a[],int n){
    int i,key,flag=0,low,high,mid;
    cout<<"Binary Search"<<endl;
               low=0;
               high=n-1;
               mid=(low+high)/2;
              cout<<"Enter key element :";
     cin>>key;
               while(low<=high){
                mid=(low+high)/2;
                if(a[mid]==key){
                    flag=1;
                    break;
                }
                else if(a[mid]<key){
                    low=mid+1;
                }
                else{
                    high=mid-1;
                }
               }
               if(flag==1){
               cout<<"key elemnt" <<key<<" is found at" <<mid<<" position"<<endl;
               }
               else{
                cout<<"key elemnt is not found"<<endl;
               }
}






 int main(){
    int i,n,key,flag=0,low,high,mid,a[i],k,ch;
    cout<<"Enter size of array :";
    cin>>n;
    cout<<"array elements are :";
    for(i=0;i<n;i++){
        cin>>a[i];
    }
    for(i=0;i<n;i++){
        cout<<a[i]<<endl;
    }
     

    do{
       cout<<"1.Linear Search\n2.Binary Search\nEnter your Choice:"<<endl;
        cin>>ch;
        switch (ch)
        {
        case 1:Linear(a,n);
               break;

        case 2:Binary(a,n);
               break;
        default:cout<<"wrong Choice"<<endl;

        }
        cout<<"do you want to continue press 1:"<<endl;
        cin>>k;

    }while(k==1);
return 0;
}